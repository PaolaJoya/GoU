package com.example.gou;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class InicioSesion extends AppCompatActivity {


    EditText TXT_USR,TXT_PASS,CAMPO_1,CAMPO_2;
    Button BTN_ING;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio_sesion);

        CAMPO_1 = (EditText)findViewById(R.id.txt_usuario);
        CAMPO_2 = (EditText)findViewById(R.id.txt_contraseñaIS);


        TXT_USR = (EditText)findViewById(R.id.txt_usuario);
        TXT_PASS = (EditText)findViewById(R.id.txt_contraseñaIS);

        BTN_ING = (Button)findViewById(R.id.button);
        BTN_ING.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String V_USR = TXT_USR.getText().toString();
                String V_PASS = TXT_PASS.getText().toString();
                if (V_USR.equals("camila")&& V_PASS.equals("12345")){
                    Intent intent=new Intent(getApplicationContext(),Ingreso.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(getApplicationContext(), "Usuario o Contraseña Erronea", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public boolean Validar(){
        boolean retorno=true;

        String c1=CAMPO_1.getText().toString();
        String c2=CAMPO_2.getText().toString();

        if (c1.isEmpty()){
            CAMPO_1.setError("Este campo no puede quedar vacio");
            retorno=false;
        }

        if (c2.isEmpty()){
            CAMPO_2.setError("Este Campo no puede quedar vacio");
            retorno=false;

        }
        return retorno;
    }
}
